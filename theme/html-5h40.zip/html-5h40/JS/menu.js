// JavaScript Document
var curUserName = parent.curUser;
if (typeof(curUserName) == "undefined")
	curUserName = '0';
var vPageMap = parent.pageMap;
if(parent.voipType!= null)
	var VoipType = parent.voipType;
else
	var VoipType = "SIP";
//if (typeof(vPageMap) == "undefined")
//	top.window.location.href="/cgi-bin/content.asp";
var sysUserName = '1';
var sptUserName = '0';
var ctcqdUserName = 'ctcqd';
var bandRegName = 'regAcc';
var usrUserName = 0;
var iCount = 0;
var IsIPv6Support = parent.IPv6Support;
if (typeof(IsIPv6Support) == "undefined")
	IsIPv6Support = 'No';
var isIpsecSupport = parent.ipsecSupport;
if (typeof(isIpsecSupport) == "undefined")
	isIpsecSupport = 'No';
var MenuArray = new Array();

var top1 = top.langfrm;

var Menu_Status = top1.Content_Status;

if("undefined" == typeof(Menu_Status))
{
	top.window.location.href="/cgi-bin/content.asp";
}
var Menu_DeviceInfo = top1.Content_DeviceInfo;
var Menu_NetInfo = top1.Content_NetInfo;
var Menu_UserInfo = top1.Content_UserInfo;
var Menu_VoIPInfo = top1.Content_VoIPInfo;
var Menu_CWMPInfo = top1.Content_CWMPInfo;

var Menu_Statistic = top1.Content_Statistic;
var Menu_ARP = top1.Content_ARP;
var Menu_WifiStation = top1.Content_WifiStation;
var Menu_SysLog = top1.Content_SysLog;
var Menu_StaticRoute = top1.Content_StaticRoute;
var Menu_LANDHCP = top1.Content_LANDHCP;

//TempPage
var Menu_Template = top1.Content_Template;

var Menu_Net = top1.Content_Net;
var Menu_WAN = top1.Content_WAN;
var Menu_Binding = top1.Content_InterfaceGrouping;
var Menu_LAN = top1.Content_LAN;
var Menu_WLAN = top1.Content_WLAN;
var Menu_WLAN5G = top1.Content_WLAN5G;
var Menu_WLAN_MESH = top1.Content_WLAN_MESH;
var Menu_CWMP = top1.Content_CWMP;
var Menu_Iphone = top1.Content_Iphone;
var Menu_Time = top1.Content_Time;
var Menu_Qos = top1.Content_Qos;
var Menu_Route = top1.Content_Route;
var Menu_Route6 = top1.Content_Route6;
var Menu_QosBand = top1.Content_QosBand;

var Menu_Security=top1.Content_Security;
var Menu_WANSet=top1.Content_WANSet;
var Menu_Firewall=top1.Content_Firewall;
var Menu_MACFilter=top1.Content_MACFilter;
var Menu_PortFilter=top1.Content_PortFilter;
var Menu_AclFilter=top1.Content_AclFilter;
var Menu_Parental=top1.Content_Parental;

var Menu_APP = top1.Content_APP;
var Menu_DDNS = top1.Content_DDNS;
var Menu_NAT = top1.Content_NAT;
var Menu_UPNP = top1.Content_UPNP;
var Menu_VoIP = top1.Content_VoIP;
var Menu_IGMPOrMLD = top1.Content_IGMPOrMLD;
var Menu_IGMP = top1.Content_IGMP;
var Menu_DailyAPP = top1.Content_DailyAPP;
var Menu_SAMBA = top1.Content_SAMBA;
var Menu_VPN = top1.Content_VPN;
var Menu_SNMP = top1.Content_SNMP;
var Menu_Others = top1.Content_Others;

var Menu_Management = top1.Content_Management;
var Menu_DeviceManagement = top1.Content_DeviceManagement;
var Menu_LogManagement = top1.Content_LogManagement;
var Menu_Upgrade = top1.Content_Upgrade;
var Menu_Backup = top1.Content_Backup;
var Menu_GPONPassword = top1.Content_GPONPassword;
var Menu_Administration = top1.Content_Administration;
var Menu_CronTab = top1.Content_CronTab; 

var Menu_Diagnose = top1.Content_Diagnose;
var Menu_InternetDiagnose = top1.Content_InternetDiagnose;
var Menu_Help = top1.Content_Help;
var Menu_UseHelp = top1.Content_UseHelp;
var Menu_VoIPBasic = top1.Content_VoIPBasic; 
var Menu_VoIPAdv = top1.Content_VoIPAdv; 

function HasStatusPages()
{
	return vPageMap[1][1] == '1'
		|| vPageMap[1][2] == '1'
		|| vPageMap[1][3] == '1'
		|| vPageMap[1][4] == '1'
		|| vPageMap[1][5] == '1'
		|| vPageMap[1][6] == '1'
		|| vPageMap[1][7] == '1'
		|| vPageMap[1][8] == '1';
}

function GetStatusLandingPage()
{
	if (vPageMap[1][1] == '1')
		return "/cgi-bin/status_deviceinfo.asp";
	if (vPageMap[1][2] == '1')
		return "/cgi-bin/sta-network.asp";
	if (vPageMap[1][3] == '1')
		return "/cgi-bin/status_arp.asp";
	if (vPageMap[1][4] == '1')
		return "/cgi-bin/status_DHCP_Clients.asp";
	if (vPageMap[1][5] == '1')
		return "/cgi-bin/status_VNPTstatistics.asp";
	if (vPageMap[1][6] == '1')
		return "/cgi-bin/status_wifi_station.asp";
	if (vPageMap[1][7] == '1')
		return "/cgi-bin/status-syslogmanage.asp";
	if (vPageMap[1][8] == '1')
		return "/cgi-bin/status_route.asp";

	return "";
}

//QS->0
//Sta->1
if ((vPageMap[1][0] == '1') || HasStatusPages()){
	var statusLandingPage = GetStatusLandingPage();
	if (statusLandingPage != "")
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_Status, statusLandingPage, "");
}
if(vPageMap[1][1] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_DeviceInfo, "/cgi-bin/status_deviceinfo.asp", "");
if(vPageMap[1][2] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_NetInfo, "/cgi-bin/sta-network.asp", "");
if(vPageMap[1][3] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_ARP, "/cgi-bin/status_arp.asp", "");
if(vPageMap[1][4] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_LANDHCP, "/cgi-bin/status_DHCP_Clients.asp", "");
if(vPageMap[1][5] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_Statistic, "/cgi-bin/status_VNPTstatistics.asp", "");
if(vPageMap[1][6] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_WifiStation, "/cgi-bin/status_wifi_station.asp", "");
if(vPageMap[1][7] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_SysLog, "/cgi-bin/status-syslogmanage.asp", "");
if(vPageMap[1][8] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_StaticRoute, "/cgi-bin/status_route.asp", "");


//Add New Page to Status Tab
//    MenuArray[iCount++] = new MenuNodeConstruction(2, "Template", "/cgi-bin/template.asp", "");

//Net->2
if(vPageMap[2][0] == '1'){
	if(vPageMap[2][1] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_Net, "/cgi-bin/net-wanset.asp", "");
	else if(vPageMap[2][3] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_Net, "/cgi-bin/net-dhcp.asp", "");
	else if(vPageMap[2][4] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_Net, "/cgi-bin/net-wlan.asp", "");
	else if(vPageMap[2][5] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_Net, "/cgi-bin/net-wlan11ac.asp", "");
	else if(vPageMap[2][2] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_Net, "/cgi-bin/net-interfacegrouping.asp", "");
}

if(vPageMap[2][1] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_WAN, "/cgi-bin/net-wanset.asp", "");
if(vPageMap[2][3] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_LAN, "/cgi-bin/net-dhcp.asp", "");
if(vPageMap[2][4] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_WLAN, "/cgi-bin/net-wlan.asp", "");
if(vPageMap[2][5] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_WLAN5G, "/cgi-bin/net-wlan11ac.asp", "");
if(vPageMap[2][14] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_WLAN_MESH, "/cgi-bin/net-wlan-mesh.asp", "");
if(vPageMap[2][2] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_Binding, "/cgi-bin/net-interfacegrouping.asp", "");

//Sec->3
if(vPageMap[3][0] == '1'){
	if(vPageMap[3][1] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_Security, "/cgi-bin/sec-urlfilter.asp", "");
//	else if(vPageMap[3][2] == '1')
//		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_Security, "/cgi-bin/sec-firewall.asp", "");
	else if(vPageMap[3][3] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_Security, "/cgi-bin/sec-macfilter.asp", "");
	else if(vPageMap[3][4] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_Security, "/cgi-bin/sec-portfilter.asp", "");				
	else if(vPageMap[3][5] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_Security, "/cgi-bin/sec-aclfilter.asp", "");				
	else if(vPageMap[3][6] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_Security, "/cgi-bin/sec-parental.asp", "");			
}
if(vPageMap[3][1] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_WANSet, "/cgi-bin/sec-urlfilter.asp", "");
//if(vPageMap[3][2] == '1')
//	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_Firewall, "/cgi-bin/sec-firewall.asp", "");
if(vPageMap[3][3] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_MACFilter, "/cgi-bin/sec-macfilter.asp", "");
if(vPageMap[3][4] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_PortFilter, "/cgi-bin/sec-portfilter.asp", "");
if(vPageMap[3][5] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_AclFilter, "/cgi-bin/sec-aclfilter.asp", "");
if(vPageMap[3][6] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_Parental, "/cgi-bin/sec-parental.asp", "");
//App->4
if(vPageMap[4][0] == '1'){
	if(vPageMap[4][1] == '1')
	{
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_APP, "/cgi-bin/app-routeset.asp", "");
	}
	else if(vPageMap[4][2] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_APP, "/cgi-bin/app-ddns.asp", "");
	else if(vPageMap[4][3] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_APP, "/cgi-bin/app-natset.asp", "");
	else if(vPageMap[4][4] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_APP, "/cgi-bin/app-upnp.asp", "");							
	else if(vPageMap[4][5] == '1') {
		if(isIpsecSupport == 'Yes')
			MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_APP, "/cgi-bin/app-ipsecList.asp", "");
	}
	else if(vPageMap[4][9] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_APP, "/cgi-bin/app-snmp.asp", "");	
	else if(vPageMap[4][10] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_APP, "/cgi-bin/wifi_multi_ap_basic.asp", "");
	else if(vPageMap[4][11] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_APP, "/cgi-bin/app-time.asp", "");
	else if (vPageMap[4][12] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_APP, "/cgi-bin/app-others.asp", "");
}
if(vPageMap[4][0] == '1'){
	if(vPageMap[4][1] == '1')
		{
			MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_Route, "/cgi-bin/app-routeset.asp", "");
			MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_Route6, "/cgi-bin/app-route6set.asp", "");
		}
	if(vPageMap[4][2] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_DDNS, "/cgi-bin/app-ddns.asp", "");
	if(vPageMap[4][3] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_NAT, "/cgi-bin/app-natset.asp", "");
	if(vPageMap[4][4] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_UPNP, "/cgi-bin/app-upnp.asp", "");

	if(vPageMap[4][5] == '1')
	{
		if(isIpsecSupport == 'Yes')
			MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_VPN, "/cgi-bin/app-ipsecList.asp", "");
	}
	if(vPageMap[4][6] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_Time, "/cgi-bin/app-time.asp", "");

	if(vPageMap[4][9] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_SNMP, "/cgi-bin/app-snmp.asp", "");
	if(vPageMap[4][10] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(2, "EasyMesh", "/cgi-bin/wifi_multi_ap_basic.asp", "");
	if(vPageMap[4][12] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_Others, "/cgi-bin/app-others.asp", "");
}

//Mag->5
if(vPageMap[5][0] == '1'){
	if(vPageMap[5][1] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_Management, "/cgi-bin/mag-changepass.asp", "");
	else if(vPageMap[5][2] == '1')
    {
        MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_Management, "/cgi-bin/upgrade.asp", "");
    }
	else if(vPageMap[5][3] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_Management, "/cgi-bin/mag-tr069.asp", "");		
	else if(vPageMap[5][4] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_Management, "/cgi-bin/upgrade.asp", "");	
	else if(vPageMap[5][5] == '1')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_CronTab, "/cgi-bin/mag-crond.asp", "");	
}
if(vPageMap[5][1] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_Administration, "/cgi-bin/mag-changepass.asp", "");
if(vPageMap[5][2] == '1')
{
    MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_Upgrade, "/cgi-bin/upgrade.asp", "");
    MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_Backup, "/cgi-bin/mag-backup.asp", "");
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_DeviceManagement, "/cgi-bin/mag-reset.asp", "");
}
if(vPageMap[5][3] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_CWMP, "/cgi-bin/mag-tr069.asp", "");
if(vPageMap[5][4] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_GPONPassword, "/cgi-bin/mag-gponpassword.asp", "");
if(vPageMap[5][5] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_CronTab, "/cgi-bin/mag-crond.asp", "");



//Diag->6
if(vPageMap[6][0] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_Diagnose, "/cgi-bin/diag-quickdiagnose.asp", "");
if(vPageMap[6][1] == '1')
	MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_InternetDiagnose, "/cgi-bin/diag-quickdiagnose.asp", "");
//Help->7
if(vPageMap[7][0] == '1')
	if(VoipType == 'H.248')
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_VoIP, "/cgi-bin/app-VoIP248.asp", "");
	else
		MenuArray[iCount++] = new MenuNodeConstruction(1, Menu_VoIP, "/cgi-bin/app-VoIP.asp", "");
if(vPageMap[7][1] == '1')
	if(VoipType == 'H.248')
		MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_VoIPBasic, "/cgi-bin/app-VoIP248.asp", "");
	else
	{
		MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_VoIPBasic, "/cgi-bin/app-VoIP.asp", "");
		MenuArray[iCount++] = new MenuNodeConstruction(2, Menu_VoIPAdv, "/cgi-bin/app-VoIP_Adv.asp", "");
	}

MenuArray[iCount++] = new MenuNodeConstruction(0, "", "", "");

function MenuNodeConstruction(Level, Text, Link, Target)
{
    this.Level = Level;
    this.Text = Text;
    this.Link = Link;
    this.Target = Target;
}

function MakeMenu(Selected_Menu)
{
	UpdateRouterMenuState(Selected_Menu);
	var Menu = Selected_Menu.split("->");
	MakeMenu_L2(Menu[1], MakeMenu_L1(Menu[0]));
}

function FindMenuIndexByLink(link)
{
	var i;
	var normalizedLink = "";

	if (link != null)
		normalizedLink = ("" + link).toLowerCase();

	for (i = 0; MenuArray[i].Level != 0; i++)
	{
		if (MenuArray[i].Link != null
		&& MenuArray[i].Link != ""
		&& MenuArray[i].Link.toLowerCase() == normalizedLink)
			return i;
	}

	return -1;
}

function FindMenuIndexByText(Selected_Menu)
{
	var Menu;
	var Menu_L1 = "";
	var Menu_L2 = "";
	var fallbackIndex = -1;
	var i;
	var menuText = "";

	if (Selected_Menu == null || Selected_Menu == "")
		return -1;

	Menu = Selected_Menu.split("->");

	if (Menu.length > 0)
		Menu_L1 = Menu[0];

	if (Menu.length > 1)
		Menu_L2 = Menu[1];

	for (i = 0; MenuArray[i].Level != 0; i++)
	{
		menuText = MenuArray[i].Text;

		if (fallbackIndex == -1
		&& Menu_L1 != ""
		&& MenuArray[i].Level == 1
		&& (menuText == Menu_L1
		|| Menu_L1.indexOf(menuText) == 0
		|| menuText.indexOf(Menu_L1) == 0))
			fallbackIndex = i;

		if (Menu_L2 != ""
		&& MenuArray[i].Level == 2
		&& (menuText == Menu_L2
		|| Menu_L2.indexOf(menuText) == 0
		|| menuText.indexOf(Menu_L2) == 0))
			return i;
	}

	return fallbackIndex;
}

function UpdateRouterMenuState(Selected_Menu)
{
	var currentIndex = -1;

	if (window.location != null && window.location.pathname != null)
		currentIndex = FindMenuIndexByLink(window.location.pathname);

	if (currentIndex == -1)
		currentIndex = FindMenuIndexByText(Selected_Menu);

	if (typeof(top) != "undefined" && top != null)
	{
		top.RouterCurrentMenu = Selected_Menu;
		top.RouterCurrentMenuIndex = currentIndex;
	}

	return currentIndex;
}

function ResolveRouterDirection(targetIndex)
{
	var currentIndex = -1;

	if (window.location != null && window.location.pathname != null)
		currentIndex = FindMenuIndexByLink(window.location.pathname);

	if (currentIndex == -1
	&& typeof(top) != "undefined"
	&& top != null
	&& typeof(top.RouterCurrentMenuIndex) != "undefined")
		currentIndex = parseInt(top.RouterCurrentMenuIndex, 10);

	if (isNaN(currentIndex))
		currentIndex = -1;

	if (currentIndex == -1 || targetIndex >= currentIndex)
		return "forward";

	return "backward";
}

function EncodeMenuText(text)
{
	if (text == null)
		return "";

	return text.replace(/&/g, "&amp;")
	           .replace(/</g, "&lt;")
	           .replace(/>/g, "&gt;")
	           .replace(/"/g, "&quot;");
}

function BuildMenuIdentity(link, fallback, index)
{
	var value = fallback || ("menu_" + index);

	if (link != null && link != "")
	{
		var startPos = link.lastIndexOf("/");
		var endPos = link.indexOf(".asp");

		if (startPos != -1 && endPos != -1 && endPos > startPos)
			value = link.substring(startPos + 1, endPos);
	}

	return value.replace(/[^A-Za-z0-9\-_:.]/g, "_");
}

function ResolveMenuDisplayText(text, link, level)
{
	var normalizedLink = "";

	if (link != null)
		normalizedLink = ("" + link).toLowerCase();

	if (level == 1 && text == Menu_Status)
		return "Status";

	if (normalizedLink.indexOf("/cgi-bin/status_deviceinfo.asp") != -1)
		return "Overview";
	if (normalizedLink.indexOf("/cgi-bin/sta-network.asp") != -1)
		return "Internet";
	if (normalizedLink.indexOf("/cgi-bin/status_arp.asp") != -1)
		return "ARP Table";
	if (normalizedLink.indexOf("/cgi-bin/status_dhcp_clients.asp") != -1)
		return "DHCP Clients";
	if (normalizedLink.indexOf("/cgi-bin/status_vnptstatistics.asp") != -1)
		return "Statistics";
	if (normalizedLink.indexOf("/cgi-bin/status_wifi_station.asp") != -1)
		return "Wi-Fi Clients";
	if (normalizedLink.indexOf("/cgi-bin/status-syslogmanage.asp") != -1)
		return "System Log";
	if (normalizedLink.indexOf("/cgi-bin/status_route.asp") != -1)
		return "Routing Table";

	return text;
}

function ResolvePageHero()
{
	var selectedMenu = getElement("Selected_Menu");

	if (selectedMenu != null && selectedMenu.parentNode != null)
		return selectedMenu.parentNode;

	return null;
}

function MakeMenu_L1(Menu_Text)
{
	var Menu_L2_Start = 0;
	var Code = '<div class="menu-shell"><div class="menu-l1">';
	
	for (iCount = 0; MenuArray[iCount].Level != 0; iCount++)
	{
		if (MenuArray[iCount].Level == 1)
		{
			if (MenuArray[iCount].Text == Menu_Text)
				Menu_L2_Start = iCount + 1;
		}
	}

	for (iCount = 0; MenuArray[iCount].Level != 0; iCount++)
	{
		var str = 'LoadPage(\'' + iCount + '\')';

		if (MenuArray[iCount].Level == 1)
		{
			var ss = BuildMenuIdentity(MenuArray[iCount].Link, MenuArray[iCount].Text, iCount);
			var activeClass = "";
			var displayText = ResolveMenuDisplayText(MenuArray[iCount].Text, MenuArray[iCount].Link, MenuArray[iCount].Level);

			if (MenuArray[iCount].Text != Menu_Text)
				activeClass = " menu-l1-item";
			else
				activeClass = " menu-l1-item is-active";

			Code += '<a href="javascript:' + str + '" target="' + MenuArray[iCount].Target + '" id="' + ss + '" name="' + ss + '" class="' + activeClass.substring(1) + '"><span>' + EncodeMenuText(displayText) + '</span></a>';
		}
	}

	Code += '<a href="https://github.com/Expl01tHunt3r/vnptmodemresearch" target="_blank" rel="noopener noreferrer" id="router_menu_github" name="router_menu_github" class="menu-l1-item menu-l1-item-external"><span>GitHub</span></a>';
	Code += '</div></div>';
	getElement('MenuArea_L1').innerHTML = Code;

	return Menu_L2_Start;
}

function LoadPage(strIndex)
{
	var index = parseInt(strIndex);
	var direction = ResolveRouterDirection(index);

	if (typeof(startRouterTabTransition) == "function")
		startRouterTabTransition(MenuArray[index].Link, direction);
	else
		top.contentfrm.location = MenuArray[index].Link;
}

function MakeMenu_L2(Menu_Text, Start)
{
	var Code = '<div class="menu-shell menu-shell-secondary"><div class="menu-l2">';

	for (var iCount = Start; (MenuArray[iCount].Level != 0) && (MenuArray[iCount].Level != 1); iCount++)
	{
		var str = 'LoadPage(\'' + iCount + '\')';

		if (MenuArray[iCount].Level == 2)
		{
			var ss = BuildMenuIdentity(MenuArray[iCount].Link, MenuArray[iCount].Text, iCount);
			var activeClass = "";
			var displayText = ResolveMenuDisplayText(MenuArray[iCount].Text, MenuArray[iCount].Link, MenuArray[iCount].Level);

			if (MenuArray[iCount].Text != Menu_Text)
				activeClass = " menu-l2-item";
			else
				activeClass = " menu-l2-item is-active";

			Code += '<a href="javascript:' + str + '" target="' + MenuArray[iCount].Target + '" id="' + ss + '" name="' + ss + '" class="' + activeClass.substring(1) + '"><span>' + EncodeMenuText(displayText) + '</span></a>';
		}
	}

	Code += '</div></div>';
	getElement('MenuArea_L2').innerHTML = Code;
}
 
function DisplayLocation(Selected_Menu)
{
	UpdateRouterMenuState(Selected_Menu);
}
